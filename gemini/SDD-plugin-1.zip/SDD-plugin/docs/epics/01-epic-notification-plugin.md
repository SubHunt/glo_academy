# Epic: SDD Notification Plugin Implementation

## Overview
Реализация легковесного плагина уведомлений на чистом JavaScript (ES6+) без внешних зависимостей. Плагин должен поддерживать позиционирование в четырех углах экрана, автоматическое скрытие по таймеру, паузу при наведении и кастомизацию через CSS-переменные.

## Environment & State
- **Язык**: Vanilla JavaScript (ES6+).
- **Стили**: Чистый CSS.
- **Сборка**: Vite (ESM и UMD форматы).
- **Глобальное состояние**: Управляется синглтоном `NotificationManager`.

### Константы и конфигурация по умолчанию
Создайте файл `src/constants.js`:
```javascript
export const DEFAULT_OPTIONS = {
  title: '',
  message: '',
  type: 'info', // 'info', 'success', 'warning', 'error'
  location: 'top-right', // 'top-right', 'top-left', 'bottom-right', 'bottom-left'
  duration: 5000, // в миллисекундах
  sticky: false // если true, не закрывается по таймеру
};

export const ICONS = {
  info: '<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
  success: '<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
  warning: '<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
  error: '<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>'
};
```

## Detailed Task List

### Task 1: CSS Architecture & Styles
**Описание**: Создание базовых стилей, переменных и анимаций для уведомлений.
**Логика реализации**:
Создать файл `src/styles.css`. Использовать префикс `sdd-notif-`.

**Код (`src/styles.css`)**:
```css
:root {
  --sdd-notif-gap: 16px;
  --sdd-notif-width: 320px;
  --sdd-notif-padding: 16px;
  --sdd-notif-radius: 8px;
  --sdd-notif-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  --sdd-notif-transition: 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
  
  /* Colors */
  --sdd-notif-bg: #ffffff;
  --sdd-notif-text: #333333;
  --sdd-notif-text-muted: #666666;
  --sdd-notif-info: #3498db;
  --sdd-notif-success: #2ecc71;
  --sdd-notif-warning: #f1c40f;
  --sdd-notif-error: #e74c3c;
}

.sdd-notif-container {
  position: fixed;
  display: flex;
  z-index: 10000;
  pointer-events: none;
  padding: var(--sdd-notif-gap);
  gap: var(--sdd-notif-gap);
}

.sdd-notif-container--top-right { top: 0; right: 0; flex-direction: column; }
.sdd-notif-container--top-left { top: 0; left: 0; flex-direction: column; }
.sdd-notif-container--bottom-right { bottom: 0; right: 0; flex-direction: column-reverse; }
.sdd-notif-container--bottom-left { bottom: 0; left: 0; flex-direction: column-reverse; }

.sdd-notif-item {
  width: var(--sdd-notif-width);
  background: var(--sdd-notif-bg);
  border-radius: var(--sdd-notif-radius);
  box-shadow: var(--sdd-notif-shadow);
  padding: var(--sdd-notif-padding);
  display: flex;
  align-items: flex-start;
  gap: 12px;
  pointer-events: auto;
  position: relative;
  overflow: hidden;
  opacity: 0;
  transition: opacity var(--sdd-notif-transition), transform var(--sdd-notif-transition), margin var(--sdd-notif-transition);
}

/* Animations */
.sdd-notif-container--top-right .sdd-notif-item,
.sdd-notif-container--bottom-right .sdd-notif-item {
  transform: translateX(100%);
}

.sdd-notif-container--top-left .sdd-notif-item,
.sdd-notif-container--bottom-left .sdd-notif-item {
  transform: translateX(-100%);
}

.sdd-notif-item.sdd-notif-item--visible {
  opacity: 1;
  transform: translateX(0);
}

.sdd-notif-item.sdd-notif-item--leaving {
  opacity: 0;
}

/* Types */
.sdd-notif-item--info .sdd-notif-item__icon { color: var(--sdd-notif-info); }
.sdd-notif-item--success .sdd-notif-item__icon { color: var(--sdd-notif-success); }
.sdd-notif-item--warning .sdd-notif-item__icon { color: var(--sdd-notif-warning); }
.sdd-notif-item--error .sdd-notif-item__icon { color: var(--sdd-notif-error); }

/* Content */
.sdd-notif-item__icon {
  flex-shrink: 0;
  display: flex;
}

.sdd-notif-item__content {
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.sdd-notif-item__title {
  font-weight: 600;
  font-size: 16px;
  color: var(--sdd-notif-text);
  margin: 0;
}

.sdd-notif-item__message {
  font-size: 14px;
  color: var(--sdd-notif-text-muted);
  margin: 0;
  line-height: 1.4;
}

.sdd-notif-item__close {
  background: none;
  border: none;
  color: var(--sdd-notif-text-muted);
  cursor: pointer;
  padding: 0;
  font-size: 20px;
  line-height: 1;
  opacity: 0.5;
  transition: opacity 0.2s;
}

.sdd-notif-item__close:hover {
  opacity: 1;
}
```

### Task 2: NotificationItem Class
**Описание**: Реализация класса для отдельного уведомления.
**Логика реализации**:
Создать файл `src/NotificationItem.js`. Класс должен управлять своим DOM-элементом, таймером и событиями.

**Код (`src/NotificationItem.js`)**:
```javascript
import { ICONS } from './constants.js';

export class NotificationItem {
  constructor(options) {
    this.options = options;
    this.domElement = null;
    this.timerId = null;
    this.remainingTime = options.duration;
    this.startTime = null;
    
    this.render();
    this.#bindEvents();
  }

  render() {
    this.domElement = document.createElement('div');
    this.domElement.className = `sdd-notif-item sdd-notif-item--${this.options.type}`;
    
    const titleHtml = this.options.title ? `<div class="sdd-notif-item__title">${this.options.title}</div>` : '';
    
    this.domElement.innerHTML = `
      <div class="sdd-notif-item__icon">${ICONS[this.options.type] || ICONS.info}</div>
      <div class="sdd-notif-item__content">
        ${titleHtml}
        <div class="sdd-notif-item__message">${this.options.message}</div>
      </div>
      <button class="sdd-notif-item__close" aria-label="Close">&times;</button>
    `;
  }

  mount(container) {
    container.appendChild(this.domElement);
    
    // Trigger reflow to enable transition
    this.domElement.offsetHeight;
    
    this.domElement.classList.add('sdd-notif-item--visible');
    
    if (!this.options.sticky) {
      this.#startTimer();
    }
  }

  destroy() {
    this.#clearTimer();
    this.domElement.classList.remove('sdd-notif-item--visible');
    this.domElement.classList.add('sdd-notif-item--leaving');
    
    // Wait for transition to finish
    this.domElement.addEventListener('transitionend', (e) => {
      if (e.propertyName === 'opacity' && this.domElement.parentNode) {
        this.domElement.parentNode.removeChild(this.domElement);
      }
    }, { once: true });
  }

  #startTimer() {
    this.startTime = Date.now();
    this.timerId = setTimeout(() => {
      this.destroy();
    }, this.remainingTime);
  }

  #clearTimer() {
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
  }

  #pauseTimer() {
    if (this.options.sticky) return;
    this.#clearTimer();
    this.remainingTime -= (Date.now() - this.startTime);
  }

  #resumeTimer() {
    if (this.options.sticky) return;
    if (this.remainingTime > 0) {
      this.#startTimer();
    } else {
      this.destroy();
    }
  }

  #bindEvents() {
    const closeBtn = this.domElement.querySelector('.sdd-notif-item__close');
    closeBtn.addEventListener('click', () => this.destroy());

    this.domElement.addEventListener('mouseenter', () => this.#pauseTimer());
    this.domElement.addEventListener('mouseleave', () => this.#resumeTimer());
  }
}
```

### Task 3: NotificationManager Class (Singleton)
**Описание**: Реализация менеджера для управления контейнерами и создания уведомлений.
**Логика реализации**:
Создать файл `src/NotificationManager.js`. Использовать паттерн Singleton.

**Код (`src/NotificationManager.js`)**:
```javascript
import { NotificationItem } from './NotificationItem.js';
import { DEFAULT_OPTIONS } from './constants.js';

class NotificationManager {
  static #instance = null;
  #containers = new Map();
  #defaults = { ...DEFAULT_OPTIONS };

  constructor() {
    if (NotificationManager.#instance) {
      return NotificationManager.#instance;
    }
    NotificationManager.#instance = this;
  }

  static getInstance() {
    if (!NotificationManager.#instance) {
      NotificationManager.#instance = new NotificationManager();
    }
    return NotificationManager.#instance;
  }

  setDefaults(options) {
    this.#defaults = { ...this.#defaults, ...options };
  }

  create(options) {
    const finalOptions = { ...this.#defaults, ...options };
    const container = this.#getContainer(finalOptions.location);
    
    const notification = new NotificationItem(finalOptions);
    notification.mount(container);
    
    return notification;
  }

  #getContainer(location) {
    if (this.#containers.has(location)) {
      return this.#containers.get(location);
    }

    const container = document.createElement('div');
    container.className = `sdd-notif-container sdd-notif-container--${location}`;
    document.body.appendChild(container);
    
    this.#containers.set(location, container);
    return container;
  }
}

export const SddNotification = NotificationManager.getInstance();
```

### Task 4: Entry Point & Vite Configuration
**Описание**: Настройка экспорта и сборки библиотеки.
**Логика реализации**:
Создать `src/index.js` для экспорта и `vite.config.js` для сборки.

**Код (`src/index.js`)**:
```javascript
import './styles.css';
export { SddNotification } from './NotificationManager.js';
```

**Код (`vite.config.js`)**:
```javascript
import { defineConfig } from 'vite';
import { resolve } from 'path';

export default defineConfig({
  build: {
    lib: {
      entry: resolve(__dirname, 'src/index.js'),
      name: 'SddNotification',
      fileName: (format) => `sdd-notification.${format === 'es' ? 'mjs' : 'umd.js'}`
    },
    rollupOptions: {
      output: {
        assetFileNames: (assetInfo) => {
          if (assetInfo.name === 'style.css') return 'sdd-notification.css';
          return assetInfo.name;
        }
      }
    }
  }
});
```

## Edge Cases
1. **Быстрое создание множества уведомлений**: Flexbox контейнеры автоматически выстраивают элементы. Анимация `transform` и `opacity` предотвращает визуальные скачки.
2. **Наведение мыши (Hover)**: При наведении на уведомление таймер ставится на паузу. При уходе мыши таймер возобновляется с оставшимся временем. Это реализовано в методах `#pauseTimer` и `#resumeTimer`.
3. **Удаление из DOM**: Использование события `transitionend` гарантирует, что элемент удаляется из DOM только после завершения анимации исчезновения. Флаг `{ once: true }` предотвращает утечки памяти.

## Verification Plan
1. Вызвать `SddNotification.create()` с разными типами (`success`, `error`, `warning`, `info`) и убедиться, что иконки и цвета соответствуют.
2. Вызвать уведомления в разных локациях (`top-right`, `bottom-left` и т.д.) и проверить корректность позиционирования и направления стекирования.
3. Навести курсор на уведомление до истечения таймера, подождать, убрать курсор. Убедиться, что уведомление не исчезает во время наведения и корректно исчезает после.
4. Проверить работу кнопки закрытия (крестик).
5. Проверить опцию `sticky: true` — уведомление не должно закрываться само.
